# Quick Start

Preview: [https://coze.cn/open-platform/realtime/websocket](https://coze.cn/open-platform/realtime/websocket)

## Prerequisites
1. Ensure you have Node.js (v18+) installed

## Running the Demo

```bash
npm run run-preinstall
npm install
npm run start

```
